#include <stdio.h>
#include <stdlib.h>
#include "utn.h"

#define LEN_LISTA    100


/*
Empleado auxiliarEmpleado[LEN_LISTA];
Empleado *pEmpleado;

pEmpleado = &auxiliarEmpleado[144];
pEmpleado->apellido;


struct sProducto
{
    int idProducto;
    int isEmpty;
};
*/

int buscarLibre(char lista[][20],
                int len,
                int* pIndex)
{
    int i;
    int ret=-1;
    for(i=0; i<len ; i++)
    {
        if(lista[i][0]=='\0')
        {
            *pIndex = i;
            ret=0;
            break;
        }
    }
    return ret;

}


int buscarNombre(char* pNombre,
                 char lista[][20],
                 int len,
                 int* pIndex
)
{
    int i;
    int ret=-1;
    for(i=0; i<len; i++)
    {
        if(strcmp(pNombre,lista[i])==0)
        {
            *pIndex = i;
            ret=0;
            break;
        }
    }
    return ret;


}


int main()
{

    int opcion;
    int i,posLibre,posAeliminar;
    char buffer[20];

    for(i=0; i<LEN_LISTA;i++)
        nombres[i][0]='\0';



    while(1)
    {

        utn_getNumber(&opcion,
                      "1)ingresar\n2)listar,4)eliminar\n",
                      "NO!",
                      1,10,2);

        printf("elegiste:%d\n",opcion);
        switch(opcion)
        {
            case 1:
            {

                break;
            }
            case 4:
            {
                // PIDO NOMBRE
                //utn_getString(buffer,...)
                fgets(buffer,20,stdin);buffer[strlen(buffer)-1]='\0';

                // en buffer esta el nombre
                buscarNombre(buffer,
                            nombres,
                            LEN_LISTA,
                            &posAeliminar);

                // borro
                nombres[posAeliminar][0]='\0';

                break;
            }
        }

    }


    return 0;
}



