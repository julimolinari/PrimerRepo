#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "empleados.h"

int emp_alta(Empleado e, int limite, int id)
{
   char nombre;
   int indice;
   utn_getString(nombre,"Ingrese un nombre: \n","Nombre inv�lido." ,2,50,3);
   emp_lugarLibreArray(Empleado[10],10,indice);
   strncpy(Empleado.nombre[indice],nombre,20);


    return 0 ;
.isEmpty
}

int emp_lugarLibreArray(Empleado array [], int limite, int* indice)
{
    int i ;
     for(i=0;i<limite;i++)
    {
        if(Empleado.isEmpty == 1)
                    {
                       *indice = i;

                    }
    }
    return 0;
}


int emp_initArray(Empleado array [], int limite)
{
    int i;
    for(i=0;i<limite;i++)
    {
       array[i].isEmpty = 1;
    }
    return 0;

}
